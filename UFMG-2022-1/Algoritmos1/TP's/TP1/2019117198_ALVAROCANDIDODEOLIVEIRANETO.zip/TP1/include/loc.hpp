#ifndef LOC_DJALV
#define LOC_DJALV

using namespace std;

typedef struct {
    int x;
    int y;
}Loc;

#endif